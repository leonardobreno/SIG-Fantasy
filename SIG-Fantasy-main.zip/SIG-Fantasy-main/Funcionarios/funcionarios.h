
// Assinaturas da funcoes relacionadas ao modulo de funcionarios
char menu_funcionario(void);
int menu_pesquisar_funcionario(char[]);
void menu_cadastro_funcionario(char[], char[], char[], char[], float*);
void menu_alterar_funcionario(char[], char[], char[], char[], float*);
void menu_deletar_funcionario(char[], char[], char[], char[], float*);
void modulo_funcionario(void);
void cad_funcinario(char nome_func[], char cpf_func[], char cel_func[], char email_func[], char salario_func[]);