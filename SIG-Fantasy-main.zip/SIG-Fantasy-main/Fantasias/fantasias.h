//Assinatura das funções do modulo fantasias
char menu_fantasia(void);
int menu_pesquisar_fantasia(char[]);
void menu_cadastro_fantasia(char[], char[], char[]);
void menu_alterar_fantasia(char[], char[], char[]);
void menu_deletar_fantasia(char[], char[], char[]);
void modulo_fantasia(void);
void cad_fantasia(char nome_fantasia[], char tamanho[], char cor[]);