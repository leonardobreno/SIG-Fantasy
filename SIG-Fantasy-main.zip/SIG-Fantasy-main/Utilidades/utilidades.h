//Assinatura das funções: "limpar_buffer"; "menu_principal"; "saida_programa"
void limpar_buffer(void);
char menu_principal(void);
char saida_programa(void);