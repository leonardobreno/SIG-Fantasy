# SIG-Fantasy 🧙‍♂️
O SIG-Fantasy é um sistema de gestão de produção e envio de fantasias!

# Funcionalidades 
- Cadastro e gerenciamento de funcionários
- Cadastro e gerenciamento de clientes
- Cadastro e gerenciamento de pedidos
- Cadastro e gerenciamento de fantasias

# Como compilar?
1- Clone o projeto

2- Execute o make run

# Projeto criado por:
Leonardo Breno da Silva Santos
leonardodbreno@gmail.com

Pedro Lucas da Silva Araújo
pedro.araujo.716@ufrn.edu.br

Thiago Gomes de Oliveira
thiago.oliveira.712@ufrn.edu.br
