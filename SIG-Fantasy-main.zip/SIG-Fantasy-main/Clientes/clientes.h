//Assinatura das funções do modulo clientes
char menu_cliente(void);
int menu_pesquisar_cliente(char[]);
void menu_cadastro_cliente(char[], char[], char[], char[]);
void menu_alterar_cliente(char[], char[], char[], char[]);
void menu_deletar_cliente(char[], char[], char[], char[]);
void modulo_cliente(void);