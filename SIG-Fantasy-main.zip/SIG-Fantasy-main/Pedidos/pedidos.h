
// Assinaturas da funcoes relacionadas ao modulo de pedidos
char menu_pedido(void);
void menu_lista_pedido(int*, int*, float*, char[]);
void menu_cadastro_pedido(int*, int*, float*, char[]);
void menu_alterar_pedido(int*, int*, float*, char[]);
void menu_deletar_pedido(int*, int*, float*, char[]);
void modulo_pedido(void);